package com.example.serverm;

import javafx.scene.layout.VBox;

import java.io.*;
import java.net.Socket;
import java.util.List;

public class ClientArray implements Runnable{
    private Socket socket;
    private BufferedWriter bufferedWriter;
    private BufferedReader bufferedReader;
    private List<ClientArray> clientArray;
    private VBox vBox;

    public ClientArray(Socket socket, VBox vBox,List<ClientArray>clientArray) {
        try
        {
            this.socket=socket;
            this.bufferedReader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.bufferedWriter=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.clientArray=clientArray;
            this.vBox=vBox;
        }
        catch(IOException e)
        {
            System.out.println("Error creating server");
            e.printStackTrace();
            closeEverything(socket,bufferedReader,bufferedWriter);
        }
    }

    //sends messages to server via bufferWriter
    //run waits for message and displays likewise
    public void sendMessageToClient(String messageToClient)
    {
        try
        {
            bufferedWriter.write(messageToClient);
            bufferedWriter.newLine();
            bufferedWriter.flush();
        }
        catch(IOException e)
        {
            e.printStackTrace();
            System.out.println("Error sending message to client");
            closeEverything(socket,bufferedReader,bufferedWriter);
        }
    }

    //closing particular client's everything if error happens
    public void closeEverything(Socket socket,BufferedReader bufferedReader,BufferedWriter bufferedWriter)
    {
        try
        {
            if(bufferedReader!=null)
                bufferedReader.close();
            if(bufferedWriter!=null)
                bufferedWriter.close();
            if(socket!=null)
                socket.close();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    //listening for messages: blocking operation
    //run will help deal with that
    //adds message we sent to our interface and uses vBox to transmit that to others
    @Override
    public void run()
    {
       try
       {
           String message;
           while((message=bufferedReader.readLine())!=null)
           {
               String messageForAllExceptMe=message;
               javafx.application.Platform.runLater(() -> {
                   HelloController.addLabel(messageForAllExceptMe, vBox);
               });
               for (ClientArray client : clientArray) {
                   if (client != this)
                   {
                       client.sendMessageToClient(messageForAllExceptMe);
                   }
               }
           }
       }
       catch(IOException e)
       {
           System.out.println("Error in client receiving and sending message");
           e.printStackTrace();
           closeEverything(socket,bufferedReader,bufferedWriter);
       }

    }
}
